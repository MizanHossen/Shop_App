import 'package:flutter/material.dart';
import 'package:store_app_with_api/widgets/feed_widget.dart';

import '../api_services/api_handler.dart';
import '../models/products_model.dart';
import 'package:http/http.dart' as http;

class FeedScreen extends StatefulWidget {
  FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  //
  late List<ProductsModel> productList = [];

  @override
  void didChangeDependencies() {
    getProducts();
    super.didChangeDependencies();
  }

  Future<void> getProducts() async {
    productList = await APIHandler.getAllProductApi();
    setState(() {});
  }

  ///

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("All Products"),
        // leading: AppBarIcons(
        //   function: () {},
        //   icon: Icons.arrow_back_ios,
        // ),
      ),
      body: productList.isEmpty
          ? Container()
          : GridView.builder(
              //shrinkWrap: true,
              //physics: const NeverScrollableScrollPhysics(),
              //itemCount: productList.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: productList.length,
                crossAxisSpacing: 10.0,
                mainAxisSpacing: 10.0,
                childAspectRatio: 0.7,
              ),
              itemBuilder: (context, index) {
                return FeedsWidget(
                  imageUrl: productList[index].images![0],
                  title: productList[index].title.toString(),
                );
              },
            ),
    );
  }
}
